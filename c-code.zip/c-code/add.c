#include "header.h"

void add_student()
{
	int i=1;

    STUDENT *new = malloc(sizeof(STUDENT));
    STUDENT * temp=head;
 while(temp)
 {
	 if(temp->id==i)
	{
		i++;
		temp=head;
        }
	 else
		 temp=temp->next;
 }
	 new->id=i;
	 printf("Enter Name: ");
    scanf(" %[^\n]",new->name);

    printf("Enter Marks: ");
    scanf("%f",&new->marks);

    new->next = NULL;

    if(head == NULL)
    {
        head = new;
    }
    else
    {
        STUDENT *temp = head;

        while(temp->next)
            temp = temp->next;

        temp->next = new;
    }

    printf("Student Added Successfully\n");
}
